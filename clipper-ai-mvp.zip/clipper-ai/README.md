# Clipper AI — MVP awal

MVP website yang dapat dijalankan sendiri. UI berbahasa Indonesia, unggah video, preview, pengaturan waktu mulai/selesai, kandidat potongan awal berbasis durasi, rasio output, dan ekspor MP4 memakai FFmpeg WebAssembly di browser.

## Fitur yang benar-benar berjalan
- Server Node.js sederhana untuk menyajikan website dan endpoint kesehatan.
- Unggah file video dari perangkat dan preview di browser.
- Potong video berdasarkan waktu mulai/selesai dan ekspor MP4 menggunakan FFmpeg WebAssembly.
- Rasio output: asli, 9:16, 1:1, 16:9.
- Kandidat Auto Clip awal berdasarkan durasi video (bukan AI sungguhan).
- Pemeriksaan format tautan YouTube. Tidak mengunduh video dari YouTube.

## Jalankan di komputer
Butuh Node.js 18 atau lebih baru.

```bash
npm start
```
Lalu buka `http://localhost:3000`.

## Jalankan dari HP Android
Pilihan termudah adalah menjalankan website ini melalui layanan hosting Node.js (misalnya layanan hosting yang mendukung aplikasi Node) setelah mengunggah folder proyek/ZIP. Atur perintah start menjadi `npm start`, dan pastikan port mengikuti variabel `PORT` yang disediakan hosting.

Jika ingin mencoba lokal dari Android:
1. Instal aplikasi terminal Android tepercaya yang dapat menjalankan Node.js, misalnya Termux dari sumber resminya.
2. Ekstrak ZIP ke folder yang bisa diakses terminal.
3. Buka terminal pada folder proyek, instal Node.js jika belum ada, lalu jalankan `npm start`.
4. Buka Chrome dan kunjungi `http://127.0.0.1:3000`.

Cara dan perintah instalasi paket terminal dapat berubah; gunakan dokumentasi resmi aplikasi terminal yang dipilih. Menjalankan FFmpeg di browser memerlukan internet saat pertama kali memuat mesin FFmpeg dari CDN. Ekspor video besar mungkin gagal pada HP dengan RAM terbatas.

## Batasan penting
- Ini MVP awal, bukan produk AI penuh. Auto Clip saat ini menghasilkan kandidat potongan secara merata berdasarkan durasi, bukan mendeteksi momen menarik.
- Pemrosesan video dasar berlangsung di perangkat; belum ada antrean render server atau model AI di backend.
- Tidak ada login, database, pembayaran, sistem kuota premium, subtitle otomatis, atau penyimpanan cloud.
- Tautan YouTube hanya divalidasi. Gunakan file yang kamu miliki atau memiliki izin untuk diedit dan patuhi ketentuan platform.
- Untuk produksi publik, tambahkan HTTPS, batas ukuran unggahan, pemantauan, keamanan, pengujian browser, serta backend pemrosesan/AI dengan autentikasi dan pengelolaan biaya.
