const $ = (id) => document.getElementById(id);
let file = null, objectUrl = null, duration = 0, ffmpeg = null, ffmpegLoading = null;
const setMessage = (el, msg, good=false) => { el.textContent = msg; el.style.color = good ? '#63e4d2' : '#ffb7a7'; };
const fmt = (s) => { s = Math.max(0, Number(s)||0); const m=Math.floor(s/60), sec=(s%60).toFixed(1).padStart(4,'0'); return `${m}:${sec}`; };
function syncRange(){
  const start=Math.max(0,Number($('startTime').value)||0), end=Math.max(0,Number($('endTime').value)||0);
  $('rangeLabel').textContent=`${start.toFixed(1)}s — ${end.toFixed(1)}s (${Math.max(0,end-start).toFixed(1)}s)`;
  $('trimRange').value=Math.min(Number($('trimRange').max),Math.max(Number($('trimRange').min),end));
}
$('videoFile').addEventListener('change', e => {
  const selected=e.target.files?.[0]; if(!selected) return;
  if(!selected.type.startsWith('video/')) { alert('Pilih file video yang valid.'); return; }
  if(objectUrl) URL.revokeObjectURL(objectUrl);
  file=selected; objectUrl=URL.createObjectURL(file); $('preview').src=objectUrl;
  $('fileName').textContent=file.name; $('emptyState').hidden=true; $('loadedState').hidden=false;
  $('candidates').innerHTML=''; $('urlMessage').textContent='Video lokal siap diedit.'; $('urlMessage').style.color='#63e4d2';
});
$('preview').addEventListener('loadedmetadata',()=>{
  duration=$('preview').duration; if(!Number.isFinite(duration)) duration=0;
  $('durationLabel').textContent=`Durasi ${fmt(duration)}`; $('startTime').value='0'; $('endTime').value=Math.min(duration,30).toFixed(1);
  $('trimRange').min='1'; $('trimRange').max=String(Math.max(1,Math.floor(duration))); $('trimRange').value=String(Math.max(1,Math.floor(Math.min(duration,30)))); syncRange();
});
$('startTime').addEventListener('input',()=>{let n=Number($('startTime').value)||0;if(duration)n=Math.min(duration,n);if(n>=Number($('endTime').value))$('endTime').value=Math.min(duration,n+1);syncRange();});
$('endTime').addEventListener('input',()=>{let n=Number($('endTime').value)||0;if(duration)n=Math.min(duration,n);if(n<=Number($('startTime').value))$('startTime').value=Math.max(0,n-1);syncRange();});
$('trimRange').addEventListener('input',()=>{$('endTime').value=$('trimRange').value;syncRange();});
$('previewClip').addEventListener('click',()=>{if(!file)return alert('Pilih video terlebih dahulu.');const start=Number($('startTime').value)||0; $('preview').currentTime=start; $('preview').play();});
$('checkUrl').addEventListener('click',async()=>{
  const url=$('ytUrl').value.trim(); if(!url){setMessage($('urlMessage'),'Masukkan tautan YouTube terlebih dahulu.');return;}
  try{const r=await fetch('/api/source-check',{method:'POST',headers:{'content-type':'application/json'},body:JSON.stringify({url})});const d=await r.json();setMessage($('urlMessage'),d.message,!!d.ok);}catch{setMessage($('urlMessage'),'Tidak bisa menghubungi server lokal. Jalankan proyek melalui npm start.');}
});
$('autoClip').addEventListener('click',()=>{
  if(!file || !duration) return alert('Pilih video dan tunggu durasinya terbaca terlebih dahulu.');
  const len=Number($('clipLength').value), count=Math.min(5,Math.max(1,Math.floor(duration/len))); const starts=[];
  if(duration<=len) starts.push(0); else for(let i=0;i<count;i++) starts.push(Math.round((duration-len)*i/Math.max(1,count-1)));
  $('candidates').innerHTML='';
  starts.forEach((start,i)=>{const end=Math.min(duration,start+len);const el=document.createElement('div');el.className='candidate';const info=document.createElement('div');info.innerHTML=`<strong>Kandidat ${i+1}</strong><small>${fmt(start)} – ${fmt(end)} · ${Math.round(end-start)} detik</small>`;const btn=document.createElement('button');btn.className='secondary';btn.textContent='Pakai klip';btn.addEventListener('click',()=>{$('startTime').value=start.toFixed(1);$('endTime').value=end.toFixed(1);syncRange();$('preview').currentTime=start;window.scrollTo({top:$('loadedState').getBoundingClientRect().top+window.scrollY-90,behavior:'smooth'});});el.append(info,btn);$('candidates').append(el);});
  const note=document.createElement('p');note.className='small-note';note.textContent='Kandidat ini dipilih merata berdasarkan durasi, bukan hasil analisis AI terhadap isi video.';$('candidates').append(note);
});
async function getFFmpeg(){
  if(ffmpeg) return ffmpeg; if(ffmpegLoading) return ffmpegLoading;
  ffmpegLoading=(async()=>{
    const { FFmpeg }=await import('https://cdn.jsdelivr.net/npm/@ffmpeg/ffmpeg@0.12.10/dist/esm/index.js');
    const { toBlobURL }=await import('https://cdn.jsdelivr.net/npm/@ffmpeg/util@0.12.1/dist/esm/index.js');
    const core='https://cdn.jsdelivr.net/npm/@ffmpeg/core@0.12.6/dist/umd';
    const instance=new FFmpeg();
    instance.on('progress',({progress})=>{const pct=Math.max(0,Math.min(99,Math.round(progress*100)));$('progressBar').style.width=`${pct}%`; $('progressPct').textContent=`${pct}%`;});
    await instance.load({coreURL:await toBlobURL(`${core}/ffmpeg-core.js`,'text/javascript'),wasmURL:await toBlobURL(`${core}/ffmpeg-core.wasm`,'application/wasm')}); ffmpeg=instance; return instance;
  })();
  try{return await ffmpegLoading;}finally{ffmpegLoading=null;}
}
$('exportBtn').addEventListener('click',async()=>{
  if(!file) return alert('Pilih video terlebih dahulu.');
  const start=Math.max(0,Number($('startTime').value)||0), end=Math.min(duration,Number($('endTime').value)||0);
  if(!(end>start)) return alert('Waktu selesai harus lebih besar dari waktu mulai.');
  if(end-start>180) { if(!confirm('Klip lebih dari 3 menit dapat berat untuk HP. Lanjutkan?')) return; }
  $('exportBtn').disabled=true;$('progressBox').hidden=false;$('progressBar').style.width='0%';$('progressPct').textContent='0%';$('progressText').textContent='Memuat mesin video…';
  try{
    const engine=await getFFmpeg();$('progressText').textContent='Memproses video di perangkat…';
    const ext=(file.name.split('.').pop()||'mp4').replace(/[^a-z0-9]/gi,'').toLowerCase()||'mp4'; const input=`input.${ext}`;const output='clipper-ai-output.mp4';
    await engine.writeFile(input,new Uint8Array(await file.arrayBuffer()));
    const args=['-ss',String(start),'-i',input,'-t',String(end-start)];
    const aspect=$('aspect').value;
    if(aspect==='9:16') args.push('-vf','scale=720:1280:force_original_aspect_ratio=decrease,pad=720:1280:(ow-iw)/2:(oh-ih)/2');
    if(aspect==='1:1') args.push('-vf','scale=720:720:force_original_aspect_ratio=decrease,pad=720:720:(ow-iw)/2:(oh-ih)/2');
    if(aspect==='16:9') args.push('-vf','scale=1280:720:force_original_aspect_ratio=decrease,pad=1280:720:(ow-iw)/2:(oh-ih)/2');
    args.push('-c:v','libx264','-preset',$('quality').value==='high'?'faster':'ultrafast','-crf',$('quality').value==='high'?'23':'28','-c:a','aac','-movflags','+faststart','-y',output);
    await engine.exec(args); const bytes=await engine.readFile(output); const blob=new Blob([bytes.buffer],{type:'video/mp4'});const url=URL.createObjectURL(blob);const a=document.createElement('a');a.href=url;a.download=`clipper-ai-${Date.now()}.mp4`;document.body.appendChild(a);a.click();a.remove();setTimeout(()=>URL.revokeObjectURL(url),60000);
    $('progressBar').style.width='100%';$('progressPct').textContent='100%';$('progressText').textContent='Selesai! Unduhan MP4 dimulai.';
    try{await engine.deleteFile(input);await engine.deleteFile(output);}catch{}
  }catch(err){console.error(err);$('progressText').textContent='Ekspor gagal.';alert('Ekspor gagal. Pastikan internet aktif untuk memuat mesin video, coba video lebih pendek, atau gunakan Chrome versi terbaru. Detail: '+(err?.message||err));}
  finally{$('exportBtn').disabled=false;}
});
